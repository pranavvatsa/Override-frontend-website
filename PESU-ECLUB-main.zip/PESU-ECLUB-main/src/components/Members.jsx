import React from 'react'

const Members = () => {
  return (
    <div>
      <h1 className='text-[#D5CEA3] text-center py-52 '> MEMBERS</h1>
    </div>
  )
}

export default Members