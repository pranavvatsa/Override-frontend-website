import React from 'react'

const About = () => {
  return (
    <div>
      <h1 className='text-[#D5CEA3] text-center py-52 '> ABOUT </h1>
    </div>
  )
}

export default About