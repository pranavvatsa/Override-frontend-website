import React from 'react'

const Home = () => {
  return (
    <div>
      <h1 className='text-[#D5CEA3] text-center py-52 '> HOME PAGE</h1>
    </div>
  )
}

export default Home